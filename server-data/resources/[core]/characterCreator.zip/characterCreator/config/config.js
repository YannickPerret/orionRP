global.config = {
    characterCreator: {
        spawn: {
            x: -817.160462,
            y: -931.239562,
            z: 15.642456,
        },
        spawnHeading: 185.275588,
    },
    defaultSkin: {
        sex: 0,
        tshirt_1: 15,
        tshirt_2: 0,
        arms: 15,
        torso_1: 15,
        torso_2: 0,
        pants_1: 14,
        pants_2: 0,
        shoes_1: 34,
        shoes_2: 0,
        helmet_1: -1,
        helmet_2: 0,
        glasses_1: -1,
        glasses_2: 0,
    }
}